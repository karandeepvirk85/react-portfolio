<?php
defined('ABSPATH') OR exit;
/**
 * Plugin Name: React
 * Plugin URI: http://vcupcode.ca
 * Description: A plugin to manage listings
 * Version: 1.3
 * Author: Karandeep Singh Virk and Stackoverflow
 * Author URI: http://vcupcode.ca
*/
?>
<?php
	include 'react_controller.php';
?>